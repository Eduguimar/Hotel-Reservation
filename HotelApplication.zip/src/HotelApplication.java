import java.text.ParseException;

public class HotelApplication {
    public static void main(String[] args) throws ParseException {
        MainMenu mainMenu = new MainMenu();
        mainMenu.start();
    }
}
