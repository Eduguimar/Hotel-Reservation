package model;

public class Tester {
    public static void main(String[] args) {
        Customer customer = new Customer("Eduardo", "Guima", "edugmail.com");

        System.out.println(customer);
    }
}
